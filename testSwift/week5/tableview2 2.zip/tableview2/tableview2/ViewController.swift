//
//  ViewController.swift
//  tableview2
//
//  Created by huan on 30/07/2021.
//
import UIKit



class ViewController: UIViewController {

    @IBOutlet weak var tableview: UITableView!
    var names: [String] = ["Honda",
                              "Vinfast",
                              "Toyota",
                              "Mercedes Benz",
                        ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Hãng"
        tableview.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableview.delegate = self
        tableview.dataSource = self
        let nib = UINib(nibName: "ErrorCell", bundle: .main)
        tableview.register(nib, forCellReuseIdentifier: "cell")
        tableview.rowHeight = UITableView.automaticDimension
        tableview.estimatedRowHeight = 50
       
    }


  

}
extension ViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ErrorCell
         cell.errorlbcell.text = names[indexPath.row]
            cell.accessoryType = .disclosureIndicator

            return cell
        
      }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch names[indexPath.row] {
        case "Vinfast":
            let vc = VinCar()
            self.navigationController?.pushViewController(vc, animated: true)
        case "Honda":
            let vc = Honda()
            self.navigationController?.pushViewController(vc, animated: true)
        default:
            print("không có dữ liệu")
        }
    }
    
    
}


