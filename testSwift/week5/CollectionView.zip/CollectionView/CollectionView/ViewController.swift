//
//  ViewController.swift
//  CollectionView
//
//  Created by huan on 05/08/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var collectionview: UICollectionView!
    
//    var users: [User] = User.getDummyDatas()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let nib = UINib(nibName: "HomeCell", bundle: .main)
        collectionview.register(nib, forCellWithReuseIdentifier: "HomeCell")
        
        collectionview.delegate = self
        collectionview.dataSource = self
        
    }

}


extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeCell", for: indexPath) as! HomeCell
        cell.configure(image: UIImage(systemName: "cart")!, lbsmall: "Mop", lbbig: "0")
        return cell
    }
}
