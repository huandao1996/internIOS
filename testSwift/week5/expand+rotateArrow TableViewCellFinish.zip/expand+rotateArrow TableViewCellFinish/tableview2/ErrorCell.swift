//
//  ErrorCell.swift
//  tableview2
//
//  Created by huan on 02/08/2021.
//

import UIKit

class ErrorCell: UITableViewCell {

    @IBOutlet weak var errorlbcell: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
