//
//  RadioButton.swift
//  day3_1_week3
//
//  Created by huan on 23/07/2021.
//

import UIKit

class RadioButton: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
