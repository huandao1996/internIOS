//
//  RadioButton.swift
//  day3_1_week3
//
//  Created by huan on 23/07/2021.
//

import UIKit

class RadioButton: BaseButton{
    // cai nay khi nua dung cai khac hay hon, cach nay k ai lam, m thoi lam luon, khi nua em se dung no qua phan tableview
    
    
    
    
    @IBOutlet var arr_button: [UIButton]!
    
    // k co cai @IBOutlet radioFemale nao nen no crash
    
    let radioOn = UIImage(named: "radio_on")! as UIImage
    let radioOff = UIImage(named:"radio_off")! as UIImage
    
    // cach khac nua la lawng nghe thuoc tinh nay
    var isChecked: Bool = false {
        didSet {
            if isChecked == true {
//                radio1.image = radioOn
//                radio2.image = radioOff
            } else {
//                radio1.image = radioOff
//                radio2.image = radioOn
            }
        }
    }
    // tr loi taij day di em
    // sao lai co 2 tam hinh
    // thì em gán để có đổi á mà
    // co nghia la nhan qua tam kia thi tam ben day bo chon dung k
     // dung roi anh
    // vay thi em phai duyet mang, de y anh dang keo collection oulet -> 1 mang outlet

    override func setupView() {
        super.setupView()
//        self.addTarget(self, action:#selector(buttonClicked1(sender:)), for: UIControl.Event.touchUpInside)
        view?.isUserInteractionEnabled = false
//        radio1.image = radioOn
//        radio2.image = radioOff
        
        for i in 0...arr_button.count - 1 {
            if i == 0 {
                arr_button[i].setImage(radioOn, for: .normal)
            } else {
                arr_button[i].setImage(radioOff, for: .normal)
            }
//            arr_button[i].addTarget(self, action: #selector(buttonClicked1(sender:)), for: .touchUpInside)
//            arr_button[i].isUserInteractionEnabled = true
        }
        
        
        
    }
    // doi ten ham nay lai, nho lai dat ten bien vaf ham phai co y nghia, thuc hien 1 chuc nang nao o, ng khac xem code ho biet dc bien do su dung lafm gi, ham su dung lam gi
    @objc func buttonClicked1(sender: UIButton) {
        if sender == self {
            isChecked = !isChecked

        }
        print(sender.tag)

    }
    
    
    @IBAction func onTapButton1(_ sender: Any) {
        print(1234)
    }
    
    @IBAction func onTapBUtton(_ sender: UIButton) {
        print(123)
    }
}

