//
//  ViewController.swift
//  day3_1_week3
//
//  Created by huan on 13/07/2021.
//

import UIKit

class ViewController: UIViewController {

    let userTextField =  textFieldLogin(frame: .init(x: 30, y: 470, width: 360, height: 70))
    let passTextField =  textFieldLogin(frame: .init(x: 30, y: 540, width: 360, height: 70))
    
    
    let reviewButton1 = CustomButton(background: .systemIndigo, title: "Facebook", image: UIImage(named: "fbicon"))
    let reviewButton2 = CustomButton(background: .systemTeal, title: "Twitter", image: UIImage(named: "twicon"))
    let reviewButton3 = CustomButton(background: .orange, title: "Login",image: nil)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUITextField()
        setupButtonUI1()
        
    }
    
    private func setupButtonUI1() {
        view.addSubview(reviewButton1)
        reviewButton1.frame = .init(x: 30, y: 200, width: 360, height: 50)
        view.addSubview(reviewButton2)
        reviewButton2.frame = .init(x: 30, y: 270, width: 360, height: 50)
        view.addSubview(reviewButton3)
        reviewButton3.frame = .init(x: 30, y: 620, width: 360, height: 50)
    }

    
    private func setupUITextField() {
        view.backgroundColor = .white
        userTextField.setTextINTextField(text: "User or email")
        passTextField.setTextINTextField(text: "Password")
        view.addSubview(userTextField)
        view.addSubview(passTextField)
    }
    
    @IBAction func buttonLogin(_ sender: Any) {
        let userData = userTextField.getText()
        let pwData = passTextField.getText()
        let vc = ViewControllerB(nibName: "ViewControllerB", bundle: nil)
        vc.receiveData(data1: userData, data2: pwData)
        navigationController?.pushViewController(vc, animated: true)
    }
        
}
