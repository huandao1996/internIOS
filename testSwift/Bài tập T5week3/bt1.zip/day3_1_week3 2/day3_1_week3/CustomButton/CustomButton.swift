//
//  CustomButton.swift
//  day3_1_week3
//
//  Created by huan on 16/07/2021.
//

import UIKit
class CustomButton: UIButton {
    
    @IBOutlet var contentView: UIView!
    
    @IBOutlet weak var lbText: UILabel!
    @IBOutlet weak var imvIcon: UIImageView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.customInit()
        
    }
    convenience init(background: UIColor, title: String, image: UIImage?) {
        self.init(frame: .zero)
        contentView.backgroundColor = background
        lbText.text = title
        imvIcon.image = image
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        // radius thi phai kiem tra xem button no co frame chua, nó chua co thi no se k radius
        layer.cornerRadius = 20
        layer.masksToBounds = true
    }
    //  init used if the view is created through IB
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.customInit()
    }
//    func configure(with viewModel: ButtonViewModel){
//        backgroundColor = viewModel.backgroundColor
//    }
    //  Do custom initialization here
    private func customInit()
    {
        Bundle.main.loadNibNamed("CustomButton", owner: self, options: nil)
        self.addSubview(self.contentView)
        self.contentView.frame = self.bounds
        self.contentView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
    }
    
}
