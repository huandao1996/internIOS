//
//  CustomButton.swift
//  day3_1_week3
//
//  Created by huan on 15/07/2021.
//

import Foundation
import UIKit

class CustomButton: UIButton {
    // keo tha cai view ben xib vao, file xib thi chi set cho file owner, k set cho cai view

    @IBOutlet var vContent: UIView!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNib()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        loadNib()
    }
    
    func loadNib() {
        // sai cho nay, button no khac
        // https://stackoverflow.com/questions/38163469/how-to-design-a-custom-uibutton-in-a-xib-file
//        let userView = Bundle.main.loadNibNamed("CustomButton", owner: self, options: nil)?.first as! UIButton
//        userView.frame = bounds
//        addSubview(userView)
        
        Bundle.main.loadNibNamed("CustomButton", owner: self, options: nil)
        addSubview(vContent)
        vContent.frame = bounds
    }

}
